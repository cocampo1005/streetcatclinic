import React from "react";

export default function ProfilePage() {
  return (
    <>
      <header className="w-full border-b-2 border-tertiaryGray p-8">
        <h1 className="font-accent text-4xl">Profile</h1>
      </header>
      <section className="p-8"></section>
    </>
  );
}
