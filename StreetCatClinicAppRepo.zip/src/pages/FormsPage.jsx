import React from "react";

export default function FormsPage() {
  return (
    <>
      <header className="w-full border-b-2 border-tertiaryGray p-8">
        <h1 className="font-accent text-4xl">Forms</h1>
      </header>
      <section className="p-8"></section>
    </>
  );
}
